import React, {useState} from 'react';
import cl from "./AdminPanel.module.css"
import Groups from "./Groups/Groups";
import Users from "./Users/Users";
import ModalDelete from "./ModalDelete/ModalDelete";
import Students from "./Students/Students";

const AdminPanel = () => {
    const [param, setParam] = useState("users")
    const [modalDelete, setModalDelete] = useState()
    const users = [
        {
            id: 1,
            name: "Admin",
            rule: "admin"
        },
        {
            id: 2,
            name: "lole",
            rule: "admin"
        },
        {
            id: 3,
            name: "lole2",
            rule: "adminssda"
        },
    ]
    const groups = [
        {
            id: 1,
            group: "11Веб241",
            tutor: "Тучина Нина Васильевна",
            countStud: 2
        },
        {
            id: 2,
            group: "11ОИБ252",
            tutor: "Брехов Денис Вадимович",
            countStud: 6
        },
        {
            id: 2,
            group: "11ИСИП252",
            tutor: "Назаренко Анастасия Александровна",
            countStud: 6
        }
    ]
    const students = [
        {
            id: 1,
            first_name: "Кирилл",
            last_name: "Елкин",
            other_name: "Романович",
            birth_date: "2003-05-14",
            phone: "+79998885544",
            address: "г. Москва, ул. Ленина, д. 15, кв. 42",
            personal_status: "Студент",
            family_status: "Не женат",
            group_id: 1,
            citizenship: "Российская Федерация",
            workplace: "Яндекс",
            education: "Среднее общее"
        },
        {
            id: 2,
            first_name: "Максим",
            last_name: "Тюльков",
            other_name: "Викторович",
            birth_date: "2002-11-23",
            phone: "+79123456789",
            address: "г. Санкт-Петербург, Невский пр., д. 88, кв. 7",
            personal_status: "Студент",
            family_status: "Не женат",
            group_id: 1,
            citizenship: "Российская Федерация",
            workplace: "",
            education: "Среднее общее"
        },
        {
            id: 3,
            first_name: "Герман",
            last_name: "Белоглазкин",
            other_name: "Александрович",
            birth_date: "2001-03-08",
            phone: "+79234567890",
            address: "г. Казань, ул. Баумана, д. 25, кв. 13",
            personal_status: "Студент",
            family_status: "Женат",
            group_id: 2,
            citizenship: "Российская Федерация",
            workplace: "Mail.ru Group",
            education: "Среднее общее"
        },
        {
            id: 4,
            first_name: "Анна",
            last_name: "Смирнова",
            other_name: "Александровна",
            birth_date: "2003-07-19",
            phone: "+79345678901",
            address: "г. Новосибирск, ул. Красный проспект, д. 50, кв. 89",
            personal_status: "Студент",
            family_status: "Не замужем",
            group_id: 1,
            citizenship: "Российская Федерация",
            workplace: "",
            education: "Среднее общее"
        },
        {
            id: 5,
            first_name: "Дмитрий",
            last_name: "Козлов",
            other_name: "Сергеевич",
            birth_date: "2002-02-28",
            phone: "+79456789012",
            address: "г. Екатеринбург, ул. 8 Марта, д. 33, кв. 156",
            personal_status: "Студент",
            family_status: "Не женат",
            group_id: 2,
            citizenship: "Российская Федерация",
            workplace: "Сбер",
            education: "Среднее общее"
        },
    ]


    return (
        <div className={cl.adminPanel}>
            <div className={cl.adminPanel__tabs}>
                <button className={`${cl.adminPanel__tabs__tab} ${param === "users" ? cl.adminPanel__tabs__tab__active : ""}`} onClick={() => setParam("users")}>
                    Пользователи
                </button>
                <button className={`${cl.adminPanel__tabs__tab} ${param === "groups" ? cl.adminPanel__tabs__tab__active : ""}`} onClick={() => setParam("groups")}>
                    Группы
                </button>
                <button className={`${cl.adminPanel__tabs__tab} ${param === "studs" ? cl.adminPanel__tabs__tab__active : ""}`} onClick={() => setParam("studs")}>
                    Студенты
                </button>
            </div>
            <Users users={users} param={param} setModalDelete={setModalDelete} />
            <Groups groups={groups} param={param} setModalDelete={setModalDelete}/>
            <Students students={students} param={param} setModalDelete={setModalDelete}/>
            <ModalDelete modalDelete={modalDelete} setModalDelete={setModalDelete}/>
        </div>
    );
};

export default AdminPanel;