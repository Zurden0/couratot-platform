import React from 'react';
import ListGroup from "../ListGroup/ListGroup";
import cl from "./Groups.module.css"

const Groups = ({groups, param, setModalDelete}) => {
    return (
        <div className={`${cl.groups} ${param === "groups" ? cl.active : ""}`}>
            <div className={cl.adminPanel__funcBlock}>
                <div className={cl.adminPanel__funcBlock__filterLine}>
                    <input className={cl.adminPanel__funcBlock__filterLine__input} type="text" placeholder='Найти группу'/>
                </div>
                <button className={cl.adminPanel__funcBlock__exitPanel}>Назад</button>
            </div>
            <div className={cl.adminPanel__mainPanel}>
                <div className={cl.adminPanel__mainPanel__params}>
                    <div className={cl.adminPanel__mainPanel__params__block}>
                        <div className={cl.adminPanel__mainPanel__params__block__param}>
                            Группа
                        </div>
                        <div className={`${cl.adminPanel__mainPanel__params__block__param} ${cl.adminPanel__mainPanel__params__block__param__main}`}>
                            Куратор
                        </div>
                        <div className={cl.adminPanel__mainPanel__params__block__param}>
                            Количество студентов
                        </div>
                    </div>
                    <div className={cl.adminPanel__mainPanel__params__block}>
                        <div className={cl.adminPanel__mainPanel__params__block__param}>
                            Действие
                        </div>
                    </div>
                </div>
                <ListGroup params={groups} setModalDelete={setModalDelete}/>
            </div>
        </div>
    );
};

export default Groups;