import React from 'react';
import ListGroupItem from '../ListGroupItem/ListGroupItem';
import cl from "./ListGroup.module.css"

const ListGroup = ({params, setModalDelete}) => {
    return (
        <div className={cl.listGroup}>
            {params.map((item, index) => {
                return (<ListGroupItem key={index} param={item} setModalDelete={setModalDelete}/>)
            })}


        </div>
    );
};

export default ListGroup;