import React from 'react';
import cl from "./ListGroupItem.module.css"
import Delete from "../../icons/Delete";
import Edit from "../../icons/Edit";

const ListGroupItem = ({param, setModalDelete}) => {
    return (
        <div className={cl.listGroupItem}>
            <div className={cl.listGroupItem__info}>
                <div className={cl.listGroupItem__info__item}>
                    {param.group ? param.group : param.id}
                </div>
                <div className={cl.listGroupItem__info__item}>
                    {param.tutor ? param.tutor : param.name}
                </div>
                <div className={cl.listGroupItem__info__item}>
                    {param.rule ? param.rule : param.countStud}
                </div>
            </div>
            <div className={cl.listGroupItem__btns}>
                <button className={cl.listGroupItem__btns__edit}><Edit/></button>
                <button className={cl.listGroupItem__btns__delete} onClick={() => setModalDelete(true)}><Delete/></button>
            </div>
        </div>
    );
};

export default ListGroupItem;