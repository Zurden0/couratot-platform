import React from 'react';
import cl from "./ModalDelete.module.css"

const ModalDelete = ({modalDelete, setModalDelete}) => {
    return (
        <div className={`${cl.modalDelete} ${modalDelete ? cl.modalDelete__active : ""}`}>
            <div className={cl.modalDelete__window}>
                <div className={cl.modalDelete__window__text}>
                    Вы уверены, что хотите удалить ?
                </div>
                <div className={cl.modalDelete__window__btns}>
                    <button className={cl.modalDelete__window__btns__btn} onClick={() => setModalDelete(false)}>
                        Удалить
                    </button>
                    <button className={cl.modalDelete__window__btns__btn} onClick={() => setModalDelete(false)}>
                        Отменить
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ModalDelete;