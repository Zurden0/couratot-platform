import React from 'react';
import cl from "./Students.module.css";
import StudentsList from "./StudentsList/StudentsList";

const Students = ({students, param, setModalDelete}) => {
    return (
        <div className={`${cl.students} ${param === "studs" ? cl.active : ""}`}>
            <div className={cl.adminPanel__funcBlock}>
                <div className={cl.adminPanel__funcBlock__filterLine}>
                    <input className={cl.adminPanel__funcBlock__filterLine__input} type="text" placeholder='Найти студента'/>
                </div>
                <button className={cl.adminPanel__funcBlock__exitPanel}>Назад</button>
            </div>
            <div className={cl.adminPanel__mainPanel}>
                <div className={cl.adminPanel__mainPanel__params}>
                    <div className={cl.adminPanel__mainPanel__params__block}>
                        <div className={cl.adminPanel__mainPanel__params__block__param}>
                            Группа
                        </div>
                        <div className={`${cl.adminPanel__mainPanel__params__block__param}`}>
                            ФИО
                        </div>
                        <div className={cl.adminPanel__mainPanel__params__block__param}>
                            Номер телефона
                        </div>
                    </div>
                    <div className={cl.adminPanel__mainPanel__params__block}>
                        <div className={cl.adminPanel__mainPanel__params__block__param}>
                            Действие
                        </div>
                    </div>
                </div>
                <StudentsList students={students} setModalDelete={setModalDelete} />
            </div>
        </div>
    );
};

export default Students;