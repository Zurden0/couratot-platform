import React, { useState } from 'react';
import cl from "./Student.module.css"
import Edit from "../../../../icons/Edit";
import Delete from "../../../../icons/Delete";
import StudentModal from "./StudentModal/StudentModal";

const Student = ({student, setModalDelete}) => {
    const [isModalOpen, setIsModalOpen] = useState(false);

    const handleOpenModal = () => {
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
    };

    return (
        <>
            <div className={cl.listGroupItem}>
                <div className={cl.listGroupItem__info} onClick={handleOpenModal}>
                    <div className={cl.listGroupItem__info__item}>
                        {student.group_id}
                    </div>
                    <div className={cl.listGroupItem__info__item}>
                        {`${student.last_name} ${student.first_name} ${student.other_name}`}
                    </div>
                    <div className={cl.listGroupItem__info__item}>
                        {student.phone}
                    </div>
                </div>
                <div className={cl.listGroupItem__btns}>
                    <button className={cl.listGroupItem__btns__edit} onClick={handleOpenModal}><Edit/></button>
                    <button className={cl.listGroupItem__btns__delete} onClick={() => setModalDelete(true)}><Delete/></button>
                </div>
            </div>

            {isModalOpen && <StudentModal student={student} onClose={handleCloseModal}/>}
        </>
    );
};

export default Student;