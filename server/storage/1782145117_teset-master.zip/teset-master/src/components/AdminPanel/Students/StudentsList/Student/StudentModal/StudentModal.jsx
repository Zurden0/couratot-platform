import React from 'react';
import cl from "./StudentModal.module.css"

const StudentModal = ({student, onClose}) => {
    if (!student) return null;

    const handleOverlayClick = (e) => {
        if (e.target === e.currentTarget) {
            onClose();
        }
    };
    return (
        <div className={cl.studentModal} onClick={handleOverlayClick}>
            <div className={cl.studentModal__window}>
                <div className={cl.studentModal__window__container}>
                    <div className={cl.studentModal__window__container__text}>Фамилия</div>
                    <div className={cl.studentModal__window__container__inputBlock}>
                        <input type="text" defaultValue={student.last_name || ""} />
                    </div>
                </div>
                <div className={cl.studentModal__window__container}>
                    <div className={cl.studentModal__window__container__text}>Имя</div>
                    <div className={cl.studentModal__window__container__inputBlock}>
                        <input type="text" defaultValue={student.first_name || ""} />
                    </div>
                </div>
                <div className={cl.studentModal__window__container}>
                    <div className={cl.studentModal__window__container__text}>Отчество</div>
                    <div className={cl.studentModal__window__container__inputBlock}>
                        <input type="text" defaultValue={student.other_name || ""} />
                    </div>
                </div>
                <div className={cl.studentModal__window__container}>
                    <div className={cl.studentModal__window__container__text}>Дата рождения</div>
                    <div className={cl.studentModal__window__container__inputBlock}>
                        <input type="date" defaultValue={student.birth_date || ""} />
                    </div>
                </div>
                <div className={cl.studentModal__window__container}>
                    <div className={cl.studentModal__window__container__text}>Телефон</div>
                    <div className={cl.studentModal__window__container__inputBlock}>
                        <input type="text" defaultValue={student.phone || ""} />
                    </div>
                </div>
                <div className={cl.studentModal__window__container}>
                    <div className={cl.studentModal__window__container__text}>Адрес</div>
                    <div className={cl.studentModal__window__container__inputBlock}>
                        <input type="text" defaultValue={student.address || ""} />
                    </div>
                </div>
                <div className={cl.studentModal__window__container}>
                    <div className={cl.studentModal__window__container__text}>Личный статус</div>
                    <div className={cl.studentModal__window__container__inputBlock}>
                        <input type="text" defaultValue={student.personal_status || ""} />
                    </div>
                </div>
                <div className={cl.studentModal__window__container}>
                    <div className={cl.studentModal__window__container__text}>Семейное положение</div>
                    <div className={cl.studentModal__window__container__inputBlock}>
                        <input type="text" defaultValue={student.family_status || ""} />
                    </div>
                </div>
                <div className={cl.studentModal__window__container}>
                    <div className={cl.studentModal__window__container__text}>Гражданство</div>
                    <div className={cl.studentModal__window__container__inputBlock}>
                        <input type="text" defaultValue={student.citizenship || ""} />
                    </div>
                </div>
                <div className={cl.studentModal__window__container}>
                    <div className={cl.studentModal__window__container__text}>Группа (ID)</div>
                    <div className={cl.studentModal__window__container__inputBlock}>
                        <input type="number" defaultValue={student.group_id || ""} />
                    </div>
                </div>
                <div className={cl.studentModal__window__container}>
                    <div className={cl.studentModal__window__container__text}>Место работы</div>
                    <div className={cl.studentModal__window__container__inputBlock}>
                        <input type="text" defaultValue={student.workplace || ""} />
                    </div>
                </div>
                <div className={cl.studentModal__window__container}>
                    <div className={cl.studentModal__window__container__text}>Образование</div>
                    <div className={cl.studentModal__window__container__inputBlock}>
                        <input type="text" defaultValue={student.education || ""} />
                    </div>
                </div>

            </div>
        </div>
    );
};

export default StudentModal;