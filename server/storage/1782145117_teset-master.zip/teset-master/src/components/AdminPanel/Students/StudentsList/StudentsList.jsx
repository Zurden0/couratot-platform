import React from 'react';
import cl from "./StudentsList.module.css"
import Student from "./Student/Student";

const StudentsList = ({students, setModalDelete}) => {
    return (
        <div className={cl.listStudents}>
            {students.map((student, index) => (
                <Student key={index} student={student} setModalDelete={setModalDelete} />
            ))}
        </div>
    );
};

export default StudentsList;