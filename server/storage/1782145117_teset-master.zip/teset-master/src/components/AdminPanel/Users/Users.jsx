import React from 'react';
import cl from "./Users.module.css";
import ListGroup from "../ListGroup/ListGroup";

const Users = ({users, param, setModalDelete}) => {
    return (
        <div className={`${cl.users} ${param === "users" ? cl.active : ""}`}>
            <div className={cl.adminPanel__funcBlock}>
                <div className={cl.adminPanel__funcBlock__filterLine}>
                    <input className={cl.adminPanel__funcBlock__filterLine__input} type="text" placeholder='Найти пользователя'/>
                </div>
                <button className={cl.adminPanel__funcBlock__exitPanel}>Назад</button>
            </div>
            <div className={cl.adminPanel__mainPanel}>
                <div className={cl.adminPanel__mainPanel__params}>
                    <div className={cl.adminPanel__mainPanel__params__block}>
                        <div className={cl.adminPanel__mainPanel__params__block__param}>
                            ID
                        </div>
                        <div className={`${cl.adminPanel__mainPanel__params__block__param} ${cl.adminPanel__mainPanel__params__block__param__main}`}>
                            Логин
                        </div>
                        <div className={cl.adminPanel__mainPanel__params__block__param}>
                            Роль
                        </div>
                    </div>
                    <div className={cl.adminPanel__mainPanel__params__block}>
                        <div className={cl.adminPanel__mainPanel__params__block__param}>
                            Действие
                        </div>
                    </div>
                </div>
                <ListGroup params={users} setModalDelete={setModalDelete}/>
            </div>
        </div>
    );
};

export default Users;